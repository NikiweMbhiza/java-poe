/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.multithreading;

/**
 *
 * @author Dell-User
 */

public class App {

    public static void main(String[] args) {
        Counter counter1 = new Counter(5, 5, "Counter 1 (High Priority)");
    Counter counter2 = new Counter(10, 10, "Counter 2 (Normal Priority)");
    Counter counter3 = new Counter(100, 100, "Counter 3 (Low Priority)");

    // Set priorities (1 = highest, 10 = lowest)
    counter1.setPriority(Thread.MAX_PRIORITY);
    counter2.setPriority(Thread.NORM_PRIORITY);
    counter3.setPriority(Thread.MIN_PRIORITY);

    // Start the threads
    counter1.start();
    counter2.start();
    counter3.start();
    }
}
class Counter extends Thread {

  private int initialValue;
  private int increment;
  private int maxIterations;
  private String name;

  public Counter(int initialValue, int increment, String name) {
    this.initialValue = initialValue;
    this.increment = increment;
    this.maxIterations = 10; // Modify this for desired number of increments
    this.name = name;
  }

  @Override
  public void run() {
    for (int i = 0; i < maxIterations; i++) {
      try {
        sleep(100); // Simulate some work
        initialValue += increment;
        System.out.println(name + ": " + initialValue);
      } catch (InterruptedException e) {
        e.printStackTrace();
      }
    }
  }
}
