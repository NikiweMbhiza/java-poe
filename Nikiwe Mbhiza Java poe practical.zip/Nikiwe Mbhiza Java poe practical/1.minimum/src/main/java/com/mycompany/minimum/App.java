/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.minimum;

/**
 *
 * @author Dell-User
 */
public class App {

    public static void main(String[] args) {
        int num1 = 10;
        int num2 = 20;
        
        int min = (num1 < num2) ? num1 : num2;
        
        System.out.println("Minimum of " + num1 + " and " + num2 + " is: " + min);
    }
}
