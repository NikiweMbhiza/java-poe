/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.stringlength;

/**
 *
 * @author Dell-User
 */
import java.util.Scanner;
public class App {

    public static void main(String[] args) {
       Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a string: ");
        String input = scanner.nextLine();
        int length = calculateLength(input);
        System.out.println("Length of the string: " + length);
        scanner.close();
    }
     public static int calculateLength(String str) {
        return str.length();
    }
}
