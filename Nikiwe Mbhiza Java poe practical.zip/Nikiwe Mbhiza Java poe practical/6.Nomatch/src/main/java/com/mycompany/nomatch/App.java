/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.nomatch;

/**
 *
 * @author Dell-User
 */
class NoMatchException extends Exception {
    public NoMatchException(String message) {
        super(message);
    }
}
public class App {

    public static void main(String[] args) {
     String inputString = "NotSymbiosis";

        try {
            // Check if the input string matches "Symbiosis"
            if (!inputString.equals("Symbiosis")) {
                throw new NoMatchException("String does not match 'Symbiosis'.");
            }
            System.out.println("String matches 'Symbiosis'.");
        } catch (NoMatchException e) {
            // Handle the custom exception
            System.out.println(e.getMessage());
        }
    }
}
