/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.random_numbers;

/**
 *
 * @author Dell-User
 */
import java.util.Random;
public class App {

    public static void main(String[] args) {
        
        Random random = new Random();
        
        for (int i = 0; i < 5; i++) {
            int randomNumber = random.nextInt(100) + 1;
            System.out.println(randomNumber);
    }   }
}
