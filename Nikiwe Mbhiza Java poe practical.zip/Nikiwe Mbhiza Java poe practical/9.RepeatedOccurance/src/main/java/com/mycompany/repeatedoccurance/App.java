/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.repeatedoccurance;

/**
 *
 * @author Dell-User
 */
public class App {

    public static void main(String[] args) {
        String word = "explanation";

        System.out.println("Successive repeated letters in the word '" + word + "':");
        detectSuccessiveRepeatedLetters(word);
    }
     public static void detectSuccessiveRepeatedLetters(String word) {
        char[] letters = word.toCharArray();

        // Iterate through each character in the word
        for (int i = 0; i < letters.length - 1; i++) {
            // Check if the current character is the same as the next character
            if (letters[i] == letters[i + 1]) {
                System.out.println("'" + letters[i] + "' occurs successively at position " + (i + 1) + " and " + (i + 2));
            }
        }
    }
}
