import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class LetterDisplay extends JFrame {
    private JLabel letterLabel;
    private int fontSize = 20;

    public LetterDisplay() {
        setTitle("Resizable Letter 'A'");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Create label with letter 'A' and initial font size
        letterLabel = new JLabel("A", SwingConstants.CENTER);
        letterLabel.setFont(new Font("Arial", Font.PLAIN, fontSize));
        add(letterLabel, BorderLayout.CENTER);

        // Add mouse click listener to increase font size on click
        letterLabel.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                fontSize += 5;
                letterLabel.setFont(new Font("Arial", Font.PLAIN, fontSize));
            }
        });

        setSize(200, 200);
        setLocationRelativeTo(null); // Center the frame
        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new LetterDisplay();
            }
        });
    }
}
