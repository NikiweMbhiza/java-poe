/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.interst;

/**
 *
 * @author Dell-User
 */
public class App {

    public static void main(String[] args) {
       // Check if all three command-line arguments are provided
        if (args.length != 3) {
            System.out.println("Usage: java SimpleInterestCalculator <principal> <time> <rate>");
            return;
        }
        
        // Parse command-line arguments into double values
        double principal = Double.parseDouble(args[0]);
        double time = Double.parseDouble(args[1]);
        double rate = Double.parseDouble(args[2]);
        
        // Calculate simple interest
        double simpleInterest = (principal * time * rate) / 100;
        
        // Print the simple interest
        System.out.println(simpleInterest);
    }
}
