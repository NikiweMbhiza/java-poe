/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.decimaltoroman;

/**
 *
 * @author Dell-User
 */
public class App {

    public static void main(String[] args) {
       if (args.length != 1) {
      System.out.println("Error: Please provide a single decimal number as input.");
      return;
    }
       try {
      int number = Integer.parseInt(args[0]);
      if (number < 1 || number > 3999) {
        System.out.println("Error: Please enter a number between 1 and 3999.");
        return;
      }
      String romanNumeral = convertToRoman(number);
      System.out.println(number + " in Roman numerals is: " + romanNumeral);
    } catch (NumberFormatException e) {
      System.out.println("Error: Please enter a valid integer.");
    }
    }
    public static String convertToRoman(int number) {
    StringBuilder romanNumeral = new StringBuilder();
    int[] values = {1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1};
    String[] romanLetters = {"M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I"};

    for (int i = 0; i < values.length; i++) {
      while (number >= values[i]) {
        number -= values[i];
        romanNumeral.append(romanLetters[i]);
      }
    }
    return romanNumeral.toString();
  }
}
