import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class TimeApplet extends JApplet implements ActionListener {
    private JButton morningButton, afternoonButton, eveningButton;
    private JLabel messageLabel;

    public void init() {
        setLayout(new FlowLayout());

        morningButton = new JButton("Morning");
        afternoonButton = new JButton("Afternoon");
        eveningButton = new JButton("Evening");

        morningButton.addActionListener(this);
        afternoonButton.addActionListener(this);
        eveningButton.addActionListener(this);

        add(morningButton);
        add(afternoonButton);
        add(eveningButton);

        messageLabel = new JLabel("");
        add(messageLabel);
    }

    public void actionPerformed(ActionEvent e) {
        String message = "";
        if (e.getSource() == morningButton) {
            message = "Good Morning to you";
            getContentPane().setBackground(Color.YELLOW);
            messageLabel.setForeground(Color.BLUE);
            messageLabel.setFont(new Font("Arial", Font.BOLD, 16));
        } else if (e.getSource() == afternoonButton) {
            message = "Good Afternoon to you";
            getContentPane().setBackground(Color.GREEN);
            messageLabel.setForeground(Color.RED);
            messageLabel.setFont(new Font("Arial", Font.BOLD, 16));
        } else if (e.getSource() == eveningButton) {
            message = "Good Evening to you";
            getContentPane().setBackground(Color.BLUE);
            messageLabel.setForeground(Color.WHITE);
            messageLabel.setFont(new Font("Arial", Font.BOLD, 16));
        }
        messageLabel.setText(message);
    }
}
