import java.applet.Applet;
import java.awt.*;

public class WelcomeApplet extends Applet {
    public void init() {
        setBackground(Color.RED);
    }

    public void paint(Graphics g) {
        g.setColor(Color.WHITE);
        g.setFont(new Font("Arial", Font.BOLD, 20));
        g.drawString("WELCOME TO THE WORLD OF APPLETS", 50, 50);
    }
}
