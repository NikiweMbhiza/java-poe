/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.classdate;

/**
 *
 * @author Dell-User
 */
import java.util.Date;
import java.text.SimpleDateFormat;
class DatePrinter {
    public void printDate() {
        Date today = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        String formattedDate = formatter.format(today);
        System.out.println("Today's Date: " + formattedDate);
    }
}

// Util class to demonstrate the usage of DatePrinter
class Util {
    // Method to use DatePrinter by creating an instance
    public static void printDateUsingInstance() {
        DatePrinter datePrinter = new DatePrinter();
        datePrinter.printDate();
    }

    // Method to use DatePrinter using an anonymous class
    public static void printDateUsingAnonymousClass() {
        DatePrinter datePrinter = new DatePrinter() {
            @Override
            public void printDate() {
                Date today = new Date();
                SimpleDateFormat formatter = new SimpleDateFormat("MMMM dd, yyyy");
                String formattedDate = formatter.format(today);
                System.out.println("Today's Date (Anonymous Class): " + formattedDate);
            }
        };
        datePrinter.printDate();
    }
}
public class App {

    public static void main(String[] args) {
       System.out.println("Using DatePrinter by creating an instance:");
        Util.printDateUsingInstance();

        System.out.println("\nUsing DatePrinter using an anonymous class:");
        Util.printDateUsingAnonymousClass();
    }
}
